 Copyright (c) 2011, 2017, Oracle and/or its affiliates. All rights reserved.

   NAME
     README.txt - Oracle Datasource for Apache Hadoop
                  Release Information

     Release 1.2.1.0 README file

  Supported Software Versions
  ===========================
  Oracle Table Access for Hadoop supports the following Hive versions:
    Hive 1.1.0

  Licensing and Installing Oracle Datasource for Apache Hadoop
  ============================================================

  See the chapter on Oracle Datasource for Apache Hadoop in Oracle Big Data 
  Connectors Software User's Guide for further information.

  Problems Fixed in Release 1.2.1.0
  =================================
  The following problems were fixed in Release 1.2.1.0:

  26226084 - JAVA.LANG.NUMBERFORMATEXCEPTION WHEN ROWSPERSPLIT ISN'T SPECIFIED

  26201381 - CHUNK BASED SPLITTERS FAIL WITH ORA-29491 WHEN OWNER NAME 
  SPECIFIED IN TABLENAME

  26237107 - ROW_SPLITTER WITH USECHUNKSPLITTER=FALSE DOESN'T THROW EXCEPTION 
  WHEN DB < 12C 

  26246632 - PREDICATE PUSHDOWN DOESN'T WORK WHEN HIVE AND ORACLE COLUMN 
  NAMES ARE DIFFERENT
  
  Problems Fixed in Release 1.2.0.0
  =================================
  The following problems were fixed in Release 1.2.0.0:

  Bug 22918283 - NUMERIC OVERFLOW EXCEPTION FOR ROW_SPLITTER AND REALLY BIG 
  TABLE IN ORACLE DB.
  Bug 22918297 - NUMBER OF THE MAPPERS DON'T MATCH WITH 
  'ORACLE.HCAT.OSH.MAXSPLITS' PARAMETER
